import mysql.connector
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

conexao = mysql.connector.connect(
    host = 'localhost',
    user = 'root',
    password = 'aluno',
    database= 'testeatiex',
)

a = [1,2,3,4,5]
b = [6,7,8,9,10]
cursor = conexao.cursor()
# Definindo o layout da página
st.set_page_config(page_title="Consulta PY", page_icon=":rocket:", layout="wide")
st.title("A night with python")
st.write("Boas-vindas ao nosso app! Aqui, demonstramos o poder do Python em criar soluções incríveis. Como aluno de ADS, estou empolgado para apresentar nosso projeto no Streamlit. Explore e descubra como o Python pode ser versátil e capaz de realizar uma infinidade de tarefas. Divirta-se explorando!")
st.divider()


comando = f'SELECT * FROM dados' 
cursor.execute(comando)
resultado = cursor.fetchall()##Lendo a tabela
st.title("Banco de dados")
st.write("Abaixo, apresentamos uma demonstração dos itens que foram enviados para o banco de dados e estão atualmente sendo exibidos em nossa tela.")
df = pd.DataFrame(resultado)
df.columns = ['Objetos encontrados', 'Frequência']
st.dataframe(df, height=800, width=800)
st.subheader("Caso deseje apagar os dados clique no botão Limpar logo abaixo")
bot = st.button("Limpar")

if bot:
    comando = f'DELETE FROM dados'
    st.success('Dados apagados com sucesso!')
    cursor.execute(comando)
    conexao.commit()

cursor.close()
conexao.close()

st.title("CSV")
st.write("Você também pode salvar esses dados em formato CSV. Exporte as informações exibidas na tela com facilidade, permitindo análises detalhadas ou compartilhamento conforme necessário. Aproveite essa funcionalidade e otimize sua experiência com nosso aplicativo!")
st.subheader("Caso deseje salvar os dados em .csv clique no botão abaixo:")
botao = st.button("Importar")
if botao:
    # Exportar dados para CSV
    with open('frequencia_palavras.csv', 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Palavra', 'Frequência'])
        for palavra, frequencia in frequencia_palavras.items():
            writer.writerow([palavra, frequencia])

    # Exportar dados para Excel
    wb = Workbook()
    ws = wb.active
    ws.append(['Palavra', 'Frequência'])
    for palavra, frequencia in frequencia_palavras.items():
        ws.append([palavra, frequencia])
    wb.save('frequencia_palavras.xlsx')
    
    # Mensagem de confirmação
    st.success('Dados salvos com sucesso em "dados.csv"')
st.divider()
chart_data = pd.DataFrame(
   {
       "col1":a,
       "col2":b,
   }
)

st.bar_chart(chart_data, x="col1", y="col2")