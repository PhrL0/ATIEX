import mysql.connector
import streamlit as st
import pandas as pd
import qrcode

conexao = mysql.connector.connect(
    host = 'localhost',
    user = 'root',
    password = 'aluno',
    database= 'testeatiex',
)

cursor = conexao.cursor()
# Definindo o layout da página
st.set_page_config(page_title="Consulta PY", page_icon=":rocket:", layout="wide")
st.title("Seja todos bem-vindos")
st.title("Consulta")
st.divider()

comando = f'SELECT * FROM dados' 
cursor.execute(comando)
resultado = cursor.fetchall()##Lendo a tabela
st.subheader("Dados de Consulta:" )
df = pd.DataFrame(resultado)
df.columns = ['Objetos encontrados', 'Frequência']
st.dataframe(df, height=800, width=800)
bot= st.button("Limpar")
if bot:
    comando = f'DELETE FROM dados'
    cursor.execute(comando)
    conexao.commit()

cursor.close()
conexao.close()
