CREATE DATABASE  IF NOT EXISTS `testeatiex` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `testeatiex`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: testeatiex
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dados`
--

DROP TABLE IF EXISTS `dados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dados` (
  `objetos` varchar(45) DEFAULT NULL,
  `frequencia` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dados`
--

LOCK TABLES `dados` WRITE;
/*!40000 ALTER TABLE `dados` DISABLE KEYS */;
INSERT INTO `dados` VALUES ('Building','2'),('Road surface','1'),('Infrastructure','1'),('Asphalt','1'),('Thoroughfare','1'),('Urban design','1'),('Car','2'),('Sidewalk','1'),('Road','1'),('City','1'),('Bicycle','1'),('Cloud','1'),('Sky','1'),('Land vehicle','2'),('Wheel','2'),('Tire','2'),('Photograph','1'),('Bicycle wheel','1'),('Bicycles--Equipment and supplies','1'),('Vehicle','1'),('Automotive lighting','1'),('Automotive tire','1'),('Hood','1'),('Motor vehicle','1'),('Automotive design','1'),('Food','1'),('Ingredient','1'),('Rangpur','1'),('Tableware','1'),('Recipe','1'),('Cuisine','1'),('Dish','1'),('Egg yolk','1'),('Meyer lemon','1'),('Boiled egg','1'),('Building','2'),('Road surface','1'),('Infrastructure','1'),('Asphalt','1'),('Thoroughfare','1'),('Urban design','1'),('Car','2'),('Sidewalk','1'),('Road','1'),('City','1'),('Bicycle','1'),('Cloud','1'),('Sky','1'),('Land vehicle','2'),('Wheel','2'),('Tire','2'),('Photograph','1'),('Bicycle wheel','1'),('Bicycles--Equipment and supplies','1'),('Vehicle','1'),('Automotive lighting','1'),('Automotive tire','1'),('Hood','1'),('Motor vehicle','1'),('Automotive design','1'),('Food','1'),('Ingredient','1'),('Rangpur','1'),('Tableware','1'),('Recipe','1'),('Cuisine','1'),('Dish','1'),('Egg yolk','1'),('Meyer lemon','1'),('Boiled egg','1');
/*!40000 ALTER TABLE `dados` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-29 22:28:18
