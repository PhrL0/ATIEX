import os
import matplotlib.pyplot as plt
from google.cloud import vision
from collections import defaultdict
import csv
from openpyxl import Workbook
import mysql.connector
import streamlit as st
import pandas as pd

conexao = mysql.connector.connect(
    host = 'localhost',
    user = 'root',
    password = 'aluno',
    database= 'testeatiex',
)

cursor = conexao.cursor()

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'teste-421115-971358084ad7.json'

def detect_labels(path):
    """Detects labels in the file."""
    client = vision.ImageAnnotatorClient()

    with open(path, "rb") as image_file:
        content = image_file.read()

    image = vision.Image(content=content)

    response = client.label_detection(image=image)
    labels = response.label_annotations

    # Criar uma lista para armazenar as palavras detectadas
    palavras_detectadas = []

    for label in labels:
        # Adicionar a descrição de cada label à lista de palavras detectadas
        palavras_detectadas.append(label.description)

    # Retornar a lista de palavras detectadas
    return palavras_detectadas

imagens = ["j5.jpg", "j6.jpg"]

frequencia_palavras = defaultdict(int)

# Loop sobre cada nome de arquivo de imagem
for imagem in imagens:
    palavras = detect_labels(imagem)  # Obter palavras detectadas para a imagem atual
    for palavra in palavras:
        frequencia_palavras[palavra] += 1  # Incrementar a contagem da palavra no dicionário

# Separar as palavras e suas frequências em duas listas
palavras = list(frequencia_palavras.keys())
frequencias = list(frequencia_palavras.values())

## INSERE DADOS NO BANCO DE DADOS ##################################################
for palavra, frequencia in zip(palavras, frequencias):
    comando = f'INSERT INTO dados(objetos, frequencia) VALUES("{palavra}", "{frequencia}")'
    cursor.execute(comando)
    conexao.commit()

# Definindo o layout da página
st.set_page_config(page_title="Consulta PY", page_icon=":rocket:", layout="wide")
st.markdown("<h1 style='text-align: center;'>Uma noite com python</h1>", unsafe_allow_html=True)
st.write("Boas-vindas ao nosso app! Aqui, demonstramos o poder do Python em criar soluções incríveis. Como aluno de ADS, estou empolgado para apresentar nosso projeto no Streamlit. Explore e descubra como o Python pode ser versátil e capaz de realizar uma infinidade de tarefas. Divirta-se explorando!")
st.divider()

## IMPRIME STREAM LIST #################################################
comando1 = f'SELECT * FROM dados' 
cursor.execute(comando1)
resultado = cursor.fetchall()##Lendo a tabela
st.markdown("<h1 style='text-align: center;'>Banco de dados</h1>", unsafe_allow_html=True)
st.write("Abaixo, apresentamos uma demonstração dos itens que foram enviados para o banco de dados e estão atualmente sendo exibidos em nossa tela.")
df = pd.DataFrame(resultado)
df.columns = ['Objetos encontrados', 'Frequência']
st.dataframe(df, height=800, width=800)
st.subheader("Caso deseje apagar os dados clique no botão Limpar logo abaixo")
bot= st.button("Limpar")
if bot:
    comando1 = f'DELETE FROM dados'
    cursor.execute(comando1)
    st.success('Dados apagados com sucesso!')
    conexao.commit()


cursor.close()
conexao.close()

st.markdown("<h1 style='text-align: center;'>Excel</h1>", unsafe_allow_html=True)
st.write("Além disso, gostaríamos de destacar que nosso aplicativo oferece a funcionalidade de salvar esses dados em formato Excel. Isso significa que você pode facilmente exportar as informações exibidas na tela para um arquivo do Excel, permitindo uma análise mais aprofundada ou o compartilhamento dos dados conforme necessário. ")
st.subheader("Caso deseje salvar os dados em .xlsx clique no botão abaixo:")
botao = st.button("Importar")
if botao:
    
    # Exportar dados para Excel
    wb = Workbook()
    ws = wb.active
    ws.append(['Palavra', 'Frequência'])
    for palavra, frequencia in frequencia_palavras.items():
        ws.append([palavra, frequencia])
    wb.save('frequencia_palavras.xlsx')
    
    # Mensagem de confirmação
    st.success('Dados salvos com sucesso em "frequencia_palavras.xlsx"')
st.divider()
st.markdown("<h1 style='text-align: center;'>Histograma de Frequência</h1>", unsafe_allow_html=True)
chart_data = pd.DataFrame(
   {
       "Objetos":palavras,
       "Frequência":frequencias,
   }
)

st.bar_chart(chart_data, x="Objetos", y="Frequência")
##########################################

