import os
import csv
from openpyxl import Workbook
import matplotlib.pyplot as plt
from google.cloud import vision
from collections import defaultdict
import mysql.connector
import streamlit as st

conexao = mysql.connector.connect(
    host = 'localhost',
    user = 'root',
    password = 'aluno',
    database= 'testeatiex',
)

cursor = conexao.cursor()

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'teste-421115-971358084ad7.json'

def detect_labels(path):
    """Detects labels in the file."""
    client = vision.ImageAnnotatorClient()

    with open(path, "rb") as image_file:
        content = image_file.read()

    image = vision.Image(content=content)

    response = client.label_detection(image=image)
    labels = response.label_annotations

    # Criar uma lista para armazenar as palavras detectadas
    palavras_detectadas = []

    for label in labels:
        # Adicionar a descrição de cada label à lista de palavras detectadas
        palavras_detectadas.append(label.description)

    # Retornar a lista de palavras detectadas
    return palavras_detectadas

imagens = ["j1.jpg", "j2.jpg", "j3.jpg", "j4.jpg"]

frequencia_palavras = defaultdict(int)

# Loop sobre cada nome de arquivo de imagem
for imagem in imagens:
    palavras = detect_labels(imagem)  # Obter palavras detectadas para a imagem atual
    for palavra in palavras:
        frequencia_palavras[palavra] += 1  # Incrementar a contagem da palavra no dicionário

# Separar as palavras e suas frequências em duas listas
palavras = list(frequencia_palavras.keys())
frequencias = list(frequencia_palavras.values())

# Criar o histograma
#plt.figure(figsize=(10, 6))
#plt.bar(palavras, frequencias)
#plt.xlabel('Palavra')
#plt.ylabel('Frequência')
#plt.title('Histograma de Frequência de Palavras')
#plt.xticks(rotation=90)  # Rotacionar os rótulos do eixo x para facilitar a leitura
#plt.tight_layout()

# Salvar o histograma como imagem
#plt.savefig('histograma.png')

# Exportar dados para CSV
#with open('frequencia_palavras.csv', 'w', newline='', encoding='utf-8') as csvfile:
    #writer = csv.writer(csvfile)
   #writer.writerow(['Palavra', 'Frequência'])
    #for palavra, frequencia in frequencia_palavras.items():
        #writer.writerow([palavra, frequencia])

# Exportar dados para Excel
#wb = Workbook()
#ws = wb.active
#ws.append(['Palavra', 'Frequência'])
#for palavra, frequencia in frequencia_palavras.items():
    #ws.append([palavra, frequencia])
#wb.save('frequencia_palavras.csv')

# Mostrar o histograma
#plt.show()

for palavra, frequencia in zip(palavras, frequencias):
    comando = f'INSERT INTO dados(objetos, frequencia) VALUES("{palavra}", "{frequencia}")'
    cursor.execute(comando)
    conexao.commit()


cursor.close()
conexao.close()
